import imagematrix

class ResizeableImage(imagematrix.ImageMatrix):

    # Function 'getEnergy' obtains the energy values
    # from each and every pixel, and then stores them
    # within the pixelEnergies dictionary
    def getEnergy(self):
        pixelEnergies = {}

        # Nested For-Loop iterates through the image,
        # calculating each and every pixel value
        for x in range(self.width):
            for y in range(self.height):
                if (x, y) not in pixelEnergies:
                    pixelEnergies[(x, y)] = self.energy(x, y)

        # return pixelEnergies
        return pixelEnergies

    # Function 'naive' is called in order to find the
    # best avenue to take with the pixels, using a recursive
    # model in order to find the path path to traverse

    # Naive iteration should take O(3^(n-1)) time complexity due 
    # to it's iteration sequence checking the bottomLeft,
    # bottomMiddle, and bottomRight pixel before choosing
    # one to traverse
    def naive(self, seam, energy):
        # Sets xCordinate and yCordinate to the
        # last element in the seam list
        xCordinate, yCordinate = seam[-1]

        # Ensures yCordinate has reached the last row.
        if (yCordinate + 1) == self.height:
            return seam, energy
        
        # minimumEnergy/bestSeam are set to find the minimumEnergy
        # to compare against others, and to store the current
        # best seam to follow
        minimumEnergy = None
        bestSeam = None

        # Loops through the possible combinations from the pixel finding
        # the next path: go bottom left, bottom middle, or bottom right, helping
        # explore the different avenues
        for i in range(3):
                bottomLeft = xCordinate + (i - 1)
                bottomRight = yCordinate + 1

                if ((bottomLeft < self.width) and (bottomLeft >= 0)) and ((bottomRight < self.height) and (bottomRight >= 0)):
                    # Adds the next pixel to seam, calculates the energy by
                    # adding the next pixels energy, and recursively calls
                    # the function again
                    currentSeam = seam + [(bottomLeft, bottomRight)]
                    currentEnergy = energy + self.energy(bottomLeft, bottomRight)
                    newSeam, newEnergy = self.naive(currentSeam, currentEnergy)
                    
                    # If the minimumEnergy equals none or if newEnergy is less
                    # than the minimum, set minimumEnergy to newEnergy and
                    # the bestseam path to newSeam
                    if (minimumEnergy == None) or (newEnergy < minimumEnergy):
                        minimumEnergy = newEnergy
                        bestSeam = newSeam
        # return bestSeam and minimumEnergy
        return bestSeam, minimumEnergy

    # Function 'dynamic' is used in order to find the best path
    # from bottom to top that has the least amount of energy to simualte
    # a seam carving algortihm. What differs 'dynamic' from 'naive' is
    # it's non-recursive format that is able to find seams and carve
    # the image much more rapidly and not having to check every avenue
    # possible

    # Dynamic iteration should take O(n^2) time complexity due 
    # to it's iteration sequence being primarily the images
    # row multiplied by it's column. Its checking every pixel
    def dynamic(self, pixelEnergies):
        seamDictionary = {}
        # Initialize seamDictionary with the varying row
        # of pixles it will possess and use throughout it's functionality
        for i in range(self.width):
            workingSeam = [(i, self.height - 1)]
            energy = pixelEnergies[(i, self.height - 1)]
            seamDictionary[(i, self.height - 1)] = (workingSeam, energy)

        # pixelStack is created in order to obtain the rows
        # using self.height subtracted by 2 to help from the second to
        # last row of the index, obtaining the proper index
        # seamDictionary, and pixelEnergies are captured as well,
        # being the variables it will help store information in.
        pixelStack = [(self.height - 2, seamDictionary, pixelEnergies)]

        # while iterating threough pixelStack, process the rows 
        # from second to last to first, popping to help retrieve
        # the last element, becoming the top element within the
        # stack used
        while pixelStack:
            row, seamDictionary, pixelEnergies = pixelStack.pop()

            # for column in the entire range of self.width
            # (going horizontally in the code), set the bottom variables
            # with empty seam lists with -1 as empty energy values, 
            for column in range(self.width):
                bottomLeft = ([], -1)
                bottomMiddle = ([], -1)
                bottomRight = ([], -1)

                # it then ensures that the pixels being checked are within
                # the proper boundaries, as well as getting their energy
                # value
                if row + 1 < self.height and column - 1 >= 0:
                    bottomLeft = seamDictionary[(column - 1, row + 1)]

                if row + 1 < self.height:
                    bottomMiddle = seamDictionary[(column, row + 1)]

                if row + 1 < self.height and column + 1 < self.width:
                    bottomRight = seamDictionary[(column + 1, row + 1)]

                # Helps find the minimum energy value when given the three given values
                # them being bottomLeft/middle/right. 
                minimumEnergy = None
                for seam, energy in [bottomLeft, bottomMiddle, bottomRight]:
                    if ((energy != -1) and ((minimumEnergy is None) or (energy < minimumEnergy))):
                        minimumEnergy = energy

                # If minimumEnergy and bottomLeft or bottomMiddle, it will be updated
                # with their respective energy value
                if minimumEnergy == bottomLeft[1]:
                    newEnergy = bottomLeft[0] + [(column, row)]
                    seamDictionary[(column, row)] = (newEnergy, bottomLeft[1] + pixelEnergies[(column, row)])

                elif minimumEnergy == bottomMiddle[1]:
                    newEnergy = bottomMiddle[0] + [(column, row)]
                    seamDictionary[(column, row)] = (newEnergy, bottomMiddle[1] + pixelEnergies[(column, row)])
                # elsewise, the bottomRight value
                # will become it
                else:
                    newEnergy = bottomRight[0] + [(column, row)]
                    seamDictionary[(column, row)] = (newEnergy, bottomRight[1] + pixelEnergies[(column, row)])

            # This will then help put the next row of the 
            # code onto the stack to help check next
            if row > 0:
                pixelStack.append((row - 1, seamDictionary, pixelEnergies))

        # minimumValue is set to be the first pixel
        # for the starting point
        minimumValue = seamDictionary[(0, 0)]

        # while going through the grid horizontally, set the currentDirectory
        # to be the energy value of seamDictionary(i,0). However, if the
        # currentDictionary(position 1) is less than the minmumValue(position 1)
        # then set minimumValue to be the currentDictionary
        for i in range(self.width):
            currentDictionary = seamDictionary[(i, 0)]

            if currentDictionary[1] < minimumValue[1]:
                minimumValue = currentDictionary

        # return minimumValue position at 0.
        return minimumValue[0]

    # Function 'best_seam' that determines if the
    # function will be carried out through a naive
    # or dynamic functionality, and will
    # call upon each function
    def best_seam(self, dp=True):
        # pixelEnergies equals self.getEnergy to get
        # the energy value of all the pixels within the image
        pixelEnergies = self.getEnergy()

        # if dp is true, it will execute dynamic search,
        # however if false, it will check with naive search.
        if dp == True:
            presentSeam = self.dynamic(pixelEnergies)
        else:
            presentSeam = None
            minimumEnergy = None
            # however, if naive search is utilized, it will call upon this for x
            # in the range of self.width
            # Through each iteration, it is checking each pixel in the first row
            # the currentSeam and currentEnergy will receive the tuple that is created
            # by the naive function. However, if minimumEnergy has no elements or if
            # currentEnergy is less than minimumEnergy, minimumEnergy will equal current
            # energy and seam will equal the currentSeam, with this for loop essentially
            # giving seam the best possible seam it could have currently found.
            for x in range(self.width):
                currentSeam, currentEnergy = self.naive([(x, 0)], self.energy(x, 0))
                if ((minimumEnergy is None) or (currentEnergy < minimumEnergy)):
                    minimumEnergy = currentEnergy
                    presentSeam = currentSeam
        return presentSeam
    
    # Function 'remove_best_seam' that removes the best seam
    def remove_best_seam(self):
        self.remove_seam(self.best_seam())