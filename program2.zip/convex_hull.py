import math
import sys
from typing import List
from typing import Set
from typing import Tuple

EPSILON = sys.float_info.epsilon
Point = Tuple[int, int]

def checkSameValues(val1: float, val2: float) -> float:
    if val1 == val2:
        return val1 + 0.5
    else:
        return val1

def y_intercept(p1: Point, p2: Point, x: int) -> float:
    """
    Given two points, p1 and p2, an x coordinate from a vertical line,
    compute and return the the y-intercept of the line segment p1->p2
    with the vertical line passing through x.
    """

    x1, y1 = p1
    x2, y2 = p2
    
    x1 = checkSameValues(x1, x2)
    
    slope = (y2 - y1) / (x2 - x1)
    return y1 + (x - x1) * slope

def triangle_area(a: Point, b: Point, c: Point) -> float:
    """
    Given three points a,b,c,
    computes and returns the area defined by the triangle a,b,c.
    Note that this area will be negative if a,b,c represents a clockwise sequence,
    positive if it is counter-clockwise,
    and zero if the points are collinear.
    """
    ax, ay = a
    bx, by = b
    cx, cy = c
    return ((cx - bx) * (by - ay) - (bx - ax) * (cy - by)) / 2

def clockwise_sort(points: List[Point]):
    """
    Given a list of points, sorts those points in clockwise order about their centroid.
    Note: this function modifies its argument.
    """
    # get mean x coord, mean y coord
    x_mean = sum(p[0] for p in points) / len(points)
    y_mean = sum(p[1] for p in points) / len(points)

    def angle(point: Point):
        return (math.atan2(point[1] - y_mean, point[0] - x_mean) + 2 * math.pi) % (2 * math.pi)

    points.sort(key=angle)
    return

def check_side(point1, point2, points):
    """
    Given a two points, checks if their tangent line includes points on either side, or only on one side.
    Returns true if other points are found only on one side and false if not
    """
    x1 = checkSameValues(point1[0], point2[0])
    y1 = checkSameValues(point1[1], point2[1])
    slope = (point2[1] - y1) / (point2[0] - x1)
    y_intercept = point1[1] - slope * point1[0]

    # Check if all the other points lie on the same side of the line
    left = True
    right = True
    for (x, y) in points:
        y_on_line = slope * x + y_intercept
        if y > y_on_line:
            right = False
        elif y < y_on_line:
            left = False
    if left:
        return True
    elif right:
        return True
    else:
        return False

def base_case_hull(points: List[Point]) -> Point:
    """
    Base case of the recursive algorithm.
    """
    hull_set = set()
    if len(points) <= 3:
        return points
    else:
        # Through brute force, compare each point to each other to find outter coordinates which fall on the hull
        hull = []
        for i in range(len(points)-1): 
            for j in range(1,len(points)):
                if points[i] != points[j]:
                    # if all points are on one side of the tangent of the current pair, then add to the hull list
                    if (check_side(points[i], points[j], points)):
                        hull_set.add(points[i])
                        hull_set.add(points[j])
    hull = list(hull_set)
    clockwise_sort(hull)
    return hull

def find_rightmost(points: List[Point])-> Point:
    """
    Finds the rightmost point from a list of points from the x-coordinate value.
    """
    rightmost = points[0][0]
    highIdx = 0
    for i in range(len(points)):
        if points[i][0] > rightmost:
            rightmost = points[i][0]
            highIdx = i

    return points[highIdx]

def find_leftmost(points: List[Point])-> Point:
    """
    Finds the leftmost point from a list of points from the x-coordinate value.
    """
    rightmost = points[0][0]
    lowIdx = 0
    for i in range(len(points)):
        if points[i][0] < rightmost:
            rightmost = points[i][0]
            lowIdx = i

    return points[lowIdx]

def findMiddle(rightmost: Point, leftmost: Point)-> float:
    """
    Finds the midpoint between the leftmost and rightmost from x-coordinate value to return out dividing line.
    """
    return (rightmost[0] + leftmost[0])/2

def calc_upper_tang(rightmost, leftmost, dividing_line, left, right) -> Point:
    '''
    Invariant: rightmost and leftmost form the upper tangent line for our convex hull thus far. 
    Initialization: Rightmost and leftmost start as the two points on each side needing to be merged, closest to the dividing line(which is the average of the x coordinates between left and right side). 
        Before the loop, this is the best case for the upper tangent line we have compared so far(have not compared to anything else yet)
    Maintenance: We compare the y intercept of the current best tangent pair(which is leftmost and rightmost). Next, this y intercept is compared with the y intercept
        for leftmost and the next clockwise point on the right side (leftmost+1). Another comparison is the y intercept of the current best tangent pair(leftmost and rightmost) with
        rightmost and the next counter-clockwise point on the leftside (rightmost-1). If comparisons of leftmost+1 or rightmost-1 create a better tangent line (where the y intercept is less than 
        the previous best set of points), leftmost and/or rightmost get updated to those values.
    Termination: If neither of the next sets of points compared produce a better upper tangent, we have found our upper tangent.
    '''
    while (y_intercept(rightmost, right[(right.index(leftmost)+1) %len(right)],dividing_line) < y_intercept(rightmost,leftmost,dividing_line) or y_intercept(left[(left.index(rightmost)-1)%len(left)], leftmost,dividing_line) < y_intercept(rightmost, leftmost,dividing_line)):
        if (y_intercept(rightmost, right[(right.index(leftmost)+1)%len(right)],dividing_line) < y_intercept(rightmost,leftmost,dividing_line)):
            leftmost = right[(right.index(leftmost)+1)%len(right)]
        else:
            rightmost = left[(left.index(rightmost)-1)%len(left)]

    return rightmost, leftmost

def calc_lower_tang(rightmost, leftmost, dividing_line, left, right) -> Point:
    '''
    Invariant: rightmost and leftmost form the lowest tangent line for our convex hull thus far. 
    Initialization: Rightmost and leftmost start as the two points on each side needing to be merged, closest to the dividing line(which is the average of the x coordinates between left and right side). 
        Before the loop, this is the lowest tangent line we have compared so far(have not compared to anything else yet)
    Maintenance: We compare the y intercept of the current best tangent pair(which is leftmost and rightmost). Next, this y intercept is compared with the y intercept
        for leftmost and the next clockwise point on the right side (leftmost+1). Another comparison is the y intercept of the current best tangent pair(leftmost and rightmost) with
        rightmost and the next counter-clockwise point on the leftside (rightmost-1). If comparisons of leftmost+1 or rightmost-1 create a better tangent line ( where the y intercept is greater than 
        the previous best set of points), leftmost and/or rightmost get updated to those values.
    Termination: If neither of the next sets of points compared produce a better lower tangent, we have found our lower tangent.
    '''
    while (y_intercept(rightmost, right[(right.index(leftmost)+1)%len(right)],dividing_line) > y_intercept(rightmost,leftmost,dividing_line) or y_intercept(left[(left.index(rightmost)-1)%len(left)], leftmost,dividing_line) > y_intercept(rightmost, leftmost,dividing_line)):
        if (y_intercept(rightmost, right[(right.index(leftmost)+1)%len(right)],dividing_line) > y_intercept(rightmost,leftmost,dividing_line)):
            leftmost = right[(right.index(leftmost)+1)%len(right)]
        else:
            rightmost = left[(left.index(rightmost)-1)%len(left)]
    
    return rightmost, leftmost

def merge(left: List[Point], right: List[Point]):
    rightmost = find_rightmost(left)
    leftmost = find_leftmost(right)
    dividing_line = findMiddle(rightmost, leftmost)
    clockwise_sort(right)
    clockwise_sort(left)
    
    
    upperLeft, upperRight = calc_upper_tang(rightmost, leftmost, dividing_line, left, right)
    lowerLeft, lowerRight = calc_lower_tang(rightmost, leftmost, dividing_line, left, right)

    hull = []
    
    # After lower and upper tangent points have been found, we also need to append the rest of the points in the hull

    hull.append(lowerLeft)

    # we start at the lower left and work our way clockwise to the upper left tangent
    leftIndex = left.index(lowerLeft)
    while left[leftIndex] is not upperLeft:
        hull.append(left[leftIndex])
        leftIndex = (leftIndex + 1) % len(left)
    
    hull.append(upperLeft)
    hull.append(upperRight)

    # Then we pick back up at the upperright tangent point and append the points clockwise until lower right where have our complete hull for the two sides merged
    rightIndex = right.index(upperRight)
    while right[rightIndex] is not lowerRight:
        hull.append(right[rightIndex])
        rightIndex = (rightIndex + 1) % len(right)

    hull.append(lowerRight)
    
    return hull

def separateHalfs(points: List[Point], leftpoints: Set, rightpoints: Set) -> Set:
    """
    Separate points into left and right side through finding the midpoint of the x coordinates and if the point is on the left side
    of the midpoint, it belongs in the leftside points, else it belongs in the rightside points
    """
    x_list = []
    for x,y in points:
        x_list.append(x)            
    midpointx = sum(x_list)/len(points)
    for i in range(len(points)):
        if points[i][0] < midpointx:
            leftpoints.add(points[i])
        else: 
            rightpoints.add(points[i])
    return leftpoints, rightpoints

def compute_hull(points: List[Point]) -> List[Point]:
    """
    Given a list of points, computes the convex hull around those points
    and returns only the points that are on the hull.
    """

    if (len(points)<=5):
        hull = base_case_hull(points)
        return hull
    else:
        leftpoints = set()
        rightpoints = set()
        # Separating left and right halfs by checking each point's x coordinate
        leftpoints, rightpoints = separateHalfs(points, leftpoints, rightpoints)
        '''
        Invariant: The number of points in the leftpoints and rightpoints sets each contain approx. 1/2 divided by the num of recursion calls thus far, of the initial points list.
            (unless intial number of points is <6)
        Initialization: The first time calling compute hull, we either enter the base case, or separate our halves, in which case the lengths of leftpoints and rightpoints
            is approx 1/2 of the initial points list. 
        Maintenance: Every time we call compute hull, say we are in our 4th recursion call, we can assume number of points in each division has reached 4 divided by half of the original number
            of points. If we had 100 points originally, by the 4th recursion call, it would have (0.5/4)*100 =~ 12 in each separate halfs points and so on.
        Termination: This process terminates once we reach our base case of having 5 or less points at which point we use brute force
        '''
        leftHalf = compute_hull(list(leftpoints))
        rightHalf = compute_hull(list(rightpoints))

        return merge(leftHalf, rightHalf)