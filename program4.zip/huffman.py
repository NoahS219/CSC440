import marshal
import os
import pickle
import sys
import heapq

from array import array
from typing import Dict
from typing import Tuple

# Design & Rep. --------------------------------------------------------------------------------------- #
# For this assignment, we are assigned with the tasks of filling in code for four functions, them being |
# encoding, decoding, compression, and decompression of contents within a file, and then outputting them|
# into another specified file location. Compression and decompression are the main elements of          |
# importance, with functions encode and decode being their functionality. We start with the user's input|
#                                                                                                       |
# The code searches for 4 inputs from the user, failing if anymore or any less are present. The first   |
# input required is the code call, the second is 4 different operations (-c for compression) (-v for    |
# encode) (-d for decompression) and (w for decoding). The third input is a user specified file to read |
# in from, and the final file being the file to transfer said action to. The input file is read in from |
# main, and the information from the file is stored as "_message".                                      |
#                                                                                                       |
# Next comes the operations that can take place, of which utilize the Greedy algorithm.                 |
# If Encode is called, then the function will take the message as a string of bytes and message as a    |
# string of bytes and returns the encoded message, as well as a decoded_ring which assigns each letter  |
# to their value.                                                                                       |
#                                                                                                       |
# If Compress is called, it will take in a message as a string of bytes and returns the encoded message |
# as a compressed, 8 bytes condensed long version, as well as the decoder_ring which assigns each letter|
# to their value.                                                                                       |
#                                                                                                       |
# If Decode is called, then the function will take the encoded message as a string of binary and will   |
# assist in returning the decoded message as bytes for decompress to translate into eligable text, with |
# the help of the decoder_ring                                                                          |
#                                                                                                       |
# If Decompress is called, then the function will take in the encoded message from decode as an 8 byte  |
# version and will translate it back into eligable text to read. It uses an array of bytes, and decodes |
# it through the utilization of the decode function.                                                    |
#                                                                                                       |
# Afterwards, the file wheter compressed or decompressed is created, being the end of this codes        |
# functionality                                                                                         |
# ----------------------------------------------------------------------------------------------------- #


# Runtime --------------------------------------------------------------------------------------------------------#
# The operation of the Greedy algorithm is based around lossless data compression which assigns the frequency of  |
# of characters to the amount they apprear, giving a compression of information without losing too much           |
# information, and retaining a smaller size compared to the files original size                                   |
#                                                                                                                 |
# Because of this, the Greedy algorithm performed has a runtime of O(n log n), and this is due to various         |
# separate factors. The building of the character frequencies takes about n time since n is the length of the data|
# being read in. The building of the branching Huffman tree takes about (log n) time because elements that have   |
# the two lowest freqency are taken to be used, combining together with the next lowest frequency, and needing to |
# be sorted after, resulting in said time. So with the building of the frequency finding functions, and the       |
# assigning of low-digit values, building up from the lowest frequency, it results in the runtime of (n log n)    |                                                                         | 
# ----------------------------------------------------------------------------------------------------------------#


# Encoding function responsible for encoding the current file 
# it's reading from into an 8 bit string
def encode(message: bytes) -> Tuple[str, Dict]:
    # Declare heapque and frequency dict
    heapQueue = []
    frequency = {}

    # Frequency finder that sees how many
    # elements appear a certain amount of time

    '''
    The implementation of iterating through the byteElements
    and obtaining the frequencies of each letter

    Initialization: The creation of the for-loop "byteElement in message"
    is used to help iterate through the characters within the contents
    obtained from the user specified file.
            
    Maintenance: Throughout the functionality of the code, this loop serves as the
    codes foundational element in which the Huffman Tree aglorithm builds upon.
    After finding the frequency of how much a character is used, it is helped
    to verify the binary value that it will have when being encoded. Placed in
    frequencyList, it will be built upon for the rest of the function
        
    Termination: This loop will end after iterating through all of the input
    files content
    '''
    for byteElement in message:
        if byteElement in frequency:
            frequency[byteElement] += 1
        else:
            frequency[byteElement] = 1
    frequencyList = list(frequency.items())

    # for the length of frequencyList, increase the 
    # count for each character, and put into a tuple
    # for each character/their frequency
    # heapify makes a heap structure to work with
    for i in range(len(frequencyList)):
        currentCharacter = frequencyList[i][0]
        frequencyOfCharacter = frequencyList[i][1]
        heapQueue.append([frequencyOfCharacter, [currentCharacter, ""]])
    heapq.heapify(heapQueue)

    # while the length of heapQue is greater than
    # 1, we apply 0's and 1's to the new list, depending
    # on each lists' elements and their positioning within
    # the heap that best represents the new characters
    # string
    '''
    The implementation of iterating through the length of heapQueue

    Initialization: The creation of the while-loop "while len(heapQueue) > 1"
    is used to help iterate through the length of the acquired heapQueue
    from the previously acquired "length of frequency" list, using and comparing
    each and every element within heapQueue
            
    Maintenance: Throughout the functionality of the code, this while loop
    serves as finding elements to pop into lowEndElement and highEndElement.
    With this, it finds the first element of the frequence of a character/characters
    andmakes the rest of the elements become character-pairs. It then pushes
    the identified index value into a single element to be placed in heapqueue
    This loop helps with combining the lowest frequency elements into a single element
    that acts as the merging element of the huffman tree algorithm

    Termination: This loop will end after iterating through every element
    within heapQueue
    '''
    while len(heapQueue) > 1:
        highEndElement = heapq.heappop(heapQueue)
        lowEndElement = heapq.heappop(heapQueue)
        # puts zeros into encoding
        for zeroIndex in lowEndElement[1:]:
            zeroIndex[1] = '0' + zeroIndex[1]
        # puts one into encoding
        for oneIndex in highEndElement[1:]:
            oneIndex[1] = '1' + oneIndex[1]
        heapq.heappush(heapQueue, [lowEndElement[0] + highEndElement[0]] + lowEndElement[1:] + highEndElement[1:])

    # Decoder Ring is declared which will help
    # create the _decoder_ring that associates the
    # users items with their byte value
    decoderRing = {}
    for i in heapQueue[0][1:]:
        characterElement, currentItem = i
        decoderRing[(characterElement)] = currentItem
    encodedMessage = ""

    for byte in message:
        currentByte = (byte)
        currentItem = decoderRing[currentByte]
        encodedMessage += currentItem
    buffcount = 0

    # While the length of the encodedMessage modulo 8 does
    # NOT equal 0, we are limiting the input to become a
    # binary string in 8 bit intervals, and then it becomes
    # included to the encoded message
    while len(encodedMessage) % 8 != 0: 
        encodedMessage = encodedMessage + "0"
        buffcount += 1
    eightBitTotal = bin(buffcount)[2:]
    eightBitTotalConfigure = '0' * (8 - len(eightBitTotal)) 
    encodedMessage = encodedMessage + eightBitTotalConfigure + eightBitTotal

    # return encodedMessage and decoderRing
    return encodedMessage, decoderRing

# Decode function thats able to take the
# current file and decode it
def decode(message: str, decoder_ring: Dict) -> bytes:

    # decoded file list is made, as well as
    # a buffer which helps the list stay as 
    # a list of 8 bits, subtracting by 8 in
    # order to help maintain the original list
    decodedFileList = bytearray()
    buffer = message[-8:]
    bufferElement = int(buffer, 2)
    
    # endingIndex is equated to the length of message,
    # subtracted by 8 and subtracted by the buffer element
    # to guarantee the proper length
    endingIndex = (len(message) - 8 - bufferElement)
    message = message[:endingIndex]

    # decodedList holder is created,
    # with it being affected in the bits
    # within message.
    decodedListHolder = ""
    '''
    Initialization: This code iterates through the bits found
    within the message of the file input.

    Maintenance: The creation of the for-loop "for bit in message"
    is used to help iterate through the bits within the message, putting said
    information into decodedListHolder, and tries to find a matching pair within
    decoder_ring, where if a match was found it is then placed onto decodedFileList
    resetting decodedListHolder. It helps build the decoded message by matching
    each bit sequence to the element within decoder_ring
    
    Termination: This loop will end after the entire message has been decoded
    by going through each element
    '''
    for bit in message:
        decodedListHolder += bit
        for element in decoder_ring:
            huffmanHolder = decoder_ring[element]

            # if decodedListHolder does match huffmanholder
            # then apply the current element to decodedFileList
            if decodedListHolder == huffmanHolder:
                decodedFileList.append(element)
                decodedListHolder = ""
                break
    
    # return bytes of decodedFileList as well as
    # utilizing utf-8 encoding to properly translate
    # the message
    return bytes(decodedFileList)

# Compression function thats able to take in the
# file given and compress it
def compress(message: bytes) -> Tuple[array, Dict]:

    # Call encode to get the encoded message
    binaryMessage, decoder_ring = encode(message)
    
    # Having an array of type B will store the
    # message as bytes
    byteArray = array('B')

    # for the i in rage of messageLenth, iterating through
    # chunks of 8 bits for each type of chunk
    message_length = len(binaryMessage)
    for i in range(0, message_length, 8):
        byteSegment = ""
        # for each chunk in 8 bits
        # append the bits to byteSegment
        for j in range(8):
            if i + j < message_length:
                byteSegment += binaryMessage[i + j]

        # compressIntValue is set to 0 
        # and is then used in the loop beneath which will 
        # help CompressIntValue store the value of the 
        # current byte. If the value was 1, it would need
        # to raise the power of byteSegement - 1 and j to
        # grant compressIntValue the proper input, giving
        # the value the value of it's integer representation
        compressIntValue = 0
        for j in range(len(byteSegment)):
            currentBit = byteSegment[j]
            if currentBit == '1':
                compressIntValue += 2 ** (len(byteSegment) - 1 - j)
        byteArray.append(compressIntValue)

    # return byteArrat and decoder_ring
    return byteArray, decoder_ring


# Decompress function thats able to take the given
# file and decompress it into eligable text
def decompress(message: array, decoder_ring: Dict) -> bytes:

    #binaryMessage is stored as an emptystring
    binaryMessage = ""

    # for currentByte in message,
    # declare an emptyString binaryHolderList
    # and call upon another loop in the range of 8

    '''
    The implementation of iterating through the message in order
    to help translate the encoded bits into text

    Initialization: The creation of the for-loop "currentByte in message" is
    used to go through each element and translate the text into text
            
    Maintenance: Throughout the functionality of the code, this loop serves as a
    decompression algorithm which "for i in range(8)" will iterate through each bite
    of the binary represented text, and then constructs the text through the use
    of the equation currentBit = (currentByte // (2 ** (7 - i))) % 2. This currentByte
    is then appended to the binaryHolderList which is added to binaryMessage that's
    then operated on within decode. This code helps convert data to information
    that the decode function can use.
        
    Termination: This loop will end after iterating through all of the elements
    within message
    '''
    for currentByte in message:
        binaryHolderList = ""

        # in the range of 8, the formula
        # (currentByte // (2 ** (7 - i))) % 2
        # is used to help the bit value be separated
        # and with said reminder, it's taken to become
        # currentBit. binaryHolderList will append the
        # currentBit String
        for i in range(8):
            currentBit = (currentByte // (2 ** (7 - i))) % 2
            binaryHolderList += str(currentBit)
        binaryMessage += binaryHolderList

    # decodedMessage calls upon decode, giving what it found
    # in the previous loop
    decodedMessage = decode(binaryMessage, decoder_ring)

    # return the decoded message
    return decodedMessage

# This main function checks to see if enough arguments have been
# given, and if the arguments are the ones required for this code
# in order for it to function properly
if __name__ == '__main__':
    usage = f'Usage: {sys.argv[0]} [ -c | -d | -v | -w ] infile outfile'
    if len(sys.argv) != 4:
        raise Exception(usage)

    operation = sys.argv[1]
    if operation not in {'-c', '-d', '-v', 'w'}:
        raise Exception(usage)

    infile, outfile = sys.argv[2], sys.argv[3]
    if not os.path.exists(infile):
        raise FileExistsError(f'{infile} does not exist.')

    # The different options we 
    # can utilize for this code
    if operation in {'-c', '-v'}:
        # These options beneath will assist in 
        # compression as well as encoding the code. 
        with open(infile, 'rb') as fp:
            _message = fp.read()

        if operation == '-c':
            _message, _decoder_ring = compress(_message)
            with open(outfile, 'wb') as fp:
                marshal.dump((pickle.dumps(_decoder_ring), _message), fp)
        else:
            _message, _decoder_ring = encode(_message)
            with open(outfile, 'wb') as fp:
                marshal.dump((pickle.dumps(_decoder_ring), _message), fp)
    else:
        # These options beneath will assist in 
        # decompression as well as decoding the code. 
        with open(infile, 'rb') as fp:
            pickleRick, _message = marshal.load(fp)
            _decoder_ring = pickle.loads(pickleRick)

        if operation == '-d':
            bytes_message = decompress(array('B', _message), _decoder_ring)
        else:
            bytes_message = decode(_message, _decoder_ring)
        with open(outfile, 'wb') as fp:
            fp.write(bytes_message)