import sys

def loadDictionary(infile):
    # Open file to manipulate data
    line = infile.readline()
    
    # Dictionaries for the knights and ladies
    knightDictionary = {}
    ladyDictionary = {}
    marriageDictionary = {}
    free_knights = []
    
    # Execption handling if the format of the file is not as expected
    try:
        num_couples = int(line)
    except ValueError:
        exit(1)
    
    # Invariant: Every knight begins as a a free_knight and every lady is also single. Their preferences 
    # can only include the other sex and is in order by line.index[1] as the most preferred and line.index[len(num_couples)-1] 
    # as least preferred.
    # --------------------------------------------------------------------------------------------------------------
    # Intialization:  The file is formatted to be first line as the number of couples, every line after that is either the
    # name of the knight or lady and their preference in order of ladies or knights
    # Maintenance: Every knight is documented as a free_knight and every lady does not have a proposal documented
    # in marriageDictionary
    # Termination: The loop terminates when all lines are read and preferences are stored
    
    # Count keeps track of when we are supposed to be loading into the knight or lady dictionary
    count = 0
    for line in infile:
        if(count < num_couples):
            line_values = line.strip().split(" ")
            if len(line_values) != num_couples + 1:
                exit(1)
            knight = line_values[0]
            ladies = line_values[1:]
            knightDictionary[knight] = ladies
            free_knights.append(knight)
        else:
            line_values = line.strip().split(" ")
            if len(line_values) != num_couples + 1:
                exit(1)
            lady = line_values[0]
            knights = line_values[1:]
            ladyDictionary[lady] = knights
            marriageDictionary[lady] = None
        count+=1
    return knightDictionary, ladyDictionary, free_knights, marriageDictionary

def find_knight_rank(knight, lady, ladyDictionary):
    rank = ladyDictionary[lady].index(knight)
    return rank
    
def propose_to_lady(knight, knightDictionary, ladyDictionary, free_knights, marriageDictionary):
    # Invariant: The current knight proposes to every lady in his preference list starting with the first 
    # lady in his preferences. If the lady denies, there is a knight who proposed to her previously who she 
    # prefers. The knight will never run out of ladies to propose to before he gets engaged. 
    #
    # Invariant: Any woman who is engaged either has not been engaged to before or perfers her current proposal
    # to any of her past proposals.
    # ----------------------------------------------------------------------------------------------------
    # Initialization: The knight begins as a free_knight who does not have a successful proposal
    # Maintenance: At each iteration of the loop, every woman is either engaged, or has been been proposed to
    # At each iteration of the loop, there is not knight or lady who is engaged to more than 1 partner
    # Termination: The loop terminates when the knight has gotten a tentative acceptance to a proposal
    
    # iterating through every lady in the knight's preferences until he is engaged
    for lady in knightDictionary[knight]:
        # if the lady is not married, then the knight gets to marry her and his hunt is over... for now
        if marriageDictionary[lady] == None:
            marriageDictionary[lady] = knight
            free_knights.remove(knight)
            break
        # if not, then we look at the lady's preferences
        else:
            engaged_knight = marriageDictionary[lady]
            knight_rank = find_knight_rank(knight, lady, ladyDictionary, )
            engaged_knight_rank = find_knight_rank(engaged_knight, lady, ladyDictionary)
            # if the lady likes the proposing knight more than her engaged one, she will marry the proposing one
            if engaged_knight_rank > knight_rank:
                free_knights.remove(knight)
                free_knights.append(engaged_knight)
                marriageDictionary[lady] = knight
                break     
            # If this is not the case, we just move on to proposing to the next lady in preference
                
def main():
    # Error handling for when there is no input file given 
    if len(sys.argv) < 2:
        exit(1)
    
    # Error handling for when the filename given does not exist or is not accessible
    try:
        filename = sys.argv[1]
        openFile = open(filename, 'r')
    except FileNotFoundError:
        exit(1)
    
    knightDictionary, ladyDictionary, free_knights, marriageDictionary = loadDictionary(openFile)
    
    # Invariant: As long as there are knights who have not gotten a successful proposal, each free knight
    # makes a propsal to their most preferred lady(whether or not she has tentatively agreed to another proposal
    # and keeps proposing until he is engaged. 
    # ------------------------------------------------------------------------------------------------------------
    # Initializaton: The knight listed in free_knights who has index 0 will get to propose before the ones following
    # him
    # Maintenance: As long as there are knights inside of free_knights, proposals will keep occuring. 
    # Termination: When there are no longer any knights who are not engaged, the proposals end and we have all our 
    # marriages matched.
    while(free_knights):
        for current_knight in free_knights:
            propose_to_lady(current_knight, knightDictionary, ladyDictionary, free_knights, marriageDictionary)

    for lady, knight in marriageDictionary.items():
        print(knight, lady)

main() 