from typing import List
from typing import Optional
import rubik

# Design & Rep. --------------------------------------------------------------------------------------------------#
# For this given assignment, my code is able to achieve the given task of finding the shortest path between the   |
# start and endpoint of a logically-made rubik cube. By receiving an input from the user, this code uses a variety|
# of dictionaries and lists to iterate through, helping to find the shortest path of moves required from the start|
# of the cube until the end. Utilizing the Breadth-First Search algorithm, I check each adjacent verticies of     |
# a particular vertex, onto it's next adjacent vertex continously until a working path has been met               |
# Through checking different working path-ways, my code will find the shortest path starting from the starting    |
# position and the end, and will combine the lists together to form the working path                              |
#                                                                                                                 |
# The code starts by declaring dictionaries and empty lists, of which help check positions that have              |
# been explored and lists that iterate through the total path                                                     |
#                                                                                                                 |
# Next, lists such as forward/backwardTuple are initiated which hold all rubik cube moves, with them being        |
# stored onto a Breadth-First search list iterating forwards and backwards.                                       |
#                                                                                                                 |
# Then the main Breadth-First search algorithm is thus entered which aims to search using startingPoint and       |
# endingPoint until they eventually meet, operating 7 times as thats the max amount to solve a 2x2x2 rubik cube   |                                                                                                          |
#                                                                                                                 |
# cubePosition is a variable used which is a poped element from BFS search, checking to see if the current        |
# position has been visited or not, appending found elements to new_BFS_search. If not empty, it holds the rubik  |                                                                           |
# cubes position                                                                                                  |
#                                                                                                                 |
# Now checking through the possible rubik move possibilities (up, right, etc) we apply the iterator by the        |                                                                                                               |
# current position. Using nextPosition, it sees if the current position has been visited. With this it will       |
# append the path taken to rubixPositionsSearch if it hasnt been visited, but continues the loop if it has        |
#                                                                                                                 |
# With nextPosition, we now check if it is within rubixPositionsSearch, and helps forms the paths together by     |
# returning forward & backward path merged together, as well as giving BFS_search the content from new_BFS_search |                                                                                            |                                                                                                     |
# ----------------------------------------------------------------------------------------------------------------#

# Runtime --------------------------------------------------------------------------------------------------------#
# The operation of the Breadth-First Search algorithm is to explore the adjacent vertices of a particular vertex  |
# until moving onto the next vertex, continuing this cycle until a certain goal or criteria has been reached,     |
# with this in my case being the starting point reaching the end point of a rubix cube.                           |
#                                                                                                                 |
# Due to this very fact, every edge and vertex will have to be visited in order to reach the desired goal,        | 
# giving us a runtime of O(V+E) as the total number of vertices(V) are added to the total number of edges(E),     |
# giving the total resulting time, since these elements have to occur before our result is given.                 |
# Additionally, within my implementation of the Breadth-First Search Algorithm, we could potentially              |
# have a runtime of O(1) since if the start and end point were adjacent to one another, only one move             |
# would be needed to manipulate the rubix cube, giving us the best case scenario.                                 |
# ----------------------------------------------------------------------------------------------------------------#

def shortest_path(start: rubik.Position, end: rubik.Position) -> Optional[List[rubik.Permutation]]:
    # If they meet up initially, return an empty list
    if start == end:
        return []
    
    # Dictionaries starting and ending Point are used
    # to help layout the search direction and to document
    # startIterator and backwardIterator are used to traverse
    # through starting point and ending point
    startingPoint = {start: None}
    endingPoint = {end: None}
    startIterator = {}
    backwardIterator = {}

    # This for loop iterates over the rubix cube twists
    # adds i to the startingPoint dict and endingPoint 
    # as iterating values to traverse through them
    for i in rubik.quarter_twists:
        startIterator[i] = i
        backwardIterator[rubik.perm_inverse(i)] = i

    # forward and backward tuple have the startingPoint and
    # endingPoint directory respectively, with them both
    # adding their path to BFS_search
    forwardTuple = (startIterator, startingPoint, endingPoint)
    backwardTuple = (backwardIterator, endingPoint, startingPoint)
    BFS_search = [(start, forwardTuple), (end, backwardTuple), None]
    
    #################################################
    # The core of the Breath-First Search Algorithm #
    #################################################

    # For i in range of 7, this is the max amount
    # of moves to make within the rubix cube
    for i in range(7):
        '''
        The implementation of searching through the range from 1-7

        Initialization: The creation of the for-loop "for i in range(7)"
        is used to help iterate through the max amount of iterations that
        can be performed in a 2x2x2 rubik cube
        
        Maintenance: Throughout the functionality of the code, this will use and operate many
        of the codes features, such as the Breadth-First search algorithm, creation of new
        lists to append elements together, as well as other lists which assist in finding the path
    
        Termination: This loop will end after iterating through a max of seven times
        '''
        # new BFS search path made to account for
        # the new, finalized list

        new_BFS_search = []
        '''
        The implementation of ‘new_BFS_search’ each and every runtime of the for i in range(7)

        Initialization: The creation of the list ‘new_BFS_search’ is done through each runtime 
        of the for loop as this is required to store the pathing of the search tree each and every iteration of the loop.
        
        Maintenance: Throughout the functionality of the code, ‘new_BFS_search’ is responsible for storing 
        the new search path discovered within each iteration of the Breadth-First search algorithm. 
        Additionally, it needs to make sure that positions have been visited for if they haven’t, 
        they are appended to its list. new_BFS_search maintains the capability to append “None” in 
        the event cubePosition has no elements, and to append the “nextPosition” as well as the 
        current “cubePosition” within itself.
    
        Termination: At the end of the for loop’s iteration, this list’s content is given to ‘BFS_search’ 
        '''

        while BFS_search:
            cubePosition = BFS_search.pop(0)

            if cubePosition is None:
                new_BFS_search.append(None)
                continue
            
            currentPosition = cubePosition[0]
            rubixMoves, rubixsPositions, rubixsPositionsSearch = cubePosition[1]

            # While within the rubixMoves list
            # see if the next position is within the
            # rubix cube's positions
            for i in rubixMoves:
                nextPosition = rubik.perm_apply(i, currentPosition)
                if nextPosition in rubixsPositions:
                    continue
                
                # If the nextPosition is not within the rubixPositions
                # then add it to new_BFS_search
                rubixsPositions[nextPosition] = (rubixMoves[i], currentPosition)
                new_BFS_search.append((nextPosition, cubePosition[1]))

                if nextPosition in rubixsPositionsSearch:
                    forwardPath = []
                    positionOne = nextPosition
                    
                    # While position one is not empty
                    # equate the ith_position to be the starting
                    # point as position one
                    while positionOne is not None:
                        '''
                        The implementation of “while positionOne is not empty” is 
                        used to keep track of the moves made to document the path traversal state
                        
                        Initialization: The creation of this while loop is used once 
                        we are searching through the rotation possibilities within the rubix cube. 
                        
                        Maintenance: Throughout checking each rotation possibility and ways to traverse, 
                        this while-loop is used to have “ith_position” become the startingPoint list at 
                        index “positionOne” and append this position to “ForwardPath”, as well as have 
                        positionOne become the “ith_position[1]” updating it to become the state before 
                        the one approached in it's traversal. This while loop will break if “ith_position” 
                        has no elements within it, but not before reversing “forwardPath” as well.
                    
                        Termination: This while-loop terminates if either the break-statement is reached, 
                        or if positionOne is empty.
                        '''
                        ith_position = startingPoint[positionOne]

                        if ith_position is None:
                            forwardPath.reverse()
                            break

                        forwardPath.append(ith_position[0])
                        positionOne = ith_position[1]

                    backwardPath = []
                    positionTwo = nextPosition
                    
                    # While position two is not empty
                    # equate the ith_position to be the starting
                    # point as position two
                    while positionTwo is not None:
                        '''
                        The implementation of “while positionTwo is not empty” is used to keep track 
                        of the moves made to document the path traversal state, but working in an 
                        inverse/backwards manner

                        Initialization: The creation of this while loop is used within 
                        searching through the rotation possibilities within the rubix cube.

                        Maintenance: Throughout checking each rotation possibility and ways to traverse, 
                        this while-loop is used to have “ith_position” become the endingPointlist at index 
                        “positionTwo” and append this position to “backwardPath”, as well as have positionTwo 
                        become the “ih_position[1]” updating it to become the state before the one approached 
                        in the traversal. This while loop will break if “ith_position” has no elements within 
                        it, but not before reversing “backwardPath” as well. This functionality is very similar 
                        to the given invariant above, but operates by finding the second half of the path.

                        Termination: This while-loop terminates if either the break-statement is reached, 
                        or if positionTwo is empty.
                        '''
                        ith_position = endingPoint[positionTwo]

                        if ith_position is None:
                            backwardPath.reverse()
                            break

                        backwardPath.append(ith_position[0])
                        positionTwo = ith_position[1]

                    # Concatenates forward and backwards path with
                    # slice notation to reverse the list next iteration
                    # helping find the shortest path
                    '''
                    The return of forwardPath + backwardPath[::-1] after if statement call, if 
                    nextPosition in rubixsPositionsSearch:

                    Initialization: The returning of a concatenated “forwardPath” and “backwardPath” 
                    along with a slice notation is performed if nextPosition is in rubixPositionsSearch 
                    (meaning we will need to visit the new position in question), for each possibility 
                    with checking each rubix-type rotation to perform

                    Maintenance: If within rubixPositionsSearch exists the nextPosition, 
                    a forwardPath and backwardPath become newly implemented lists, acting 
                    as the path “to-and-from” the start and end point. Through two different 
                    “while-loops” that were stated above, the path from each end is found and 
                    documented. The return statement in specific is responsible for concatenating 
                    the forward/backward path, and also reverses the list via slice notation to 
                    help assist find the shortest path

                    Termination: This invariant terminates once it is called and returns the shortest path.
                    '''
                    return forwardPath + backwardPath[::-1]
                
        # Have BFS_search equal new_BFS_search
        BFS_search = new_BFS_search

    return None